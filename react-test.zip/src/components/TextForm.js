import React, { useState } from 'react'

export default function TextForm(props) {
    const averageReadingTimePerWordInMins = 0.005;

    const getWordCount = (text) => {
        return text.split(" ").length;
    }

    const handleUpClick = () => {
        console.log("Ucase clicked");
        let upperText = text.toUpperCase();
        setText(upperText);
    }

    const handleLowClick = () => {
        console.log("Lcase clicked");
        let lowerText = text.toLowerCase();
        setText(lowerText);
    }

    const handleOnChange = (event) => {
        console.log("On Change");
        setText(event.target.value);
    }

    const [text, setText] = useState("Enter text here");
    // text = "something fun" // Invalid way
    // setText("Lol"); // Valid way

    return (
        <>
            <div>
                <h1>{props.heading}</h1>
                <div className="mb-3">
                    {/* <label htmlFor="myBox" className="form-label">Email address</label> */}
                    <textarea className="form-control" value={text} onChange={handleOnChange} id="exampleFormControlTextarea1" rows="8"></textarea>
                </div>
                <button className="btn btn-primary" onClick={handleUpClick}>Convert To Uppercase</button>
                <button className="btn btn-primary mx-1" onClick={handleLowClick}>Convert To Lowercase</button>
            </div>
            <div className="container">
                <h1>Text Summary</h1>
                <p>{getWordCount(text)} word and {text.length} characters</p>
                <p>Average reading time: {getWordCount(text)*averageReadingTimePerWordInMins}</p>
            </div>
        </>
    )
}
